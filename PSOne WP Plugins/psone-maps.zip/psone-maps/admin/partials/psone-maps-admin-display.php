<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       psone.ca
 * @since      1.0.0
 *
 * @package    Psone_Maps
 * @subpackage Psone_Maps/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div class="wrap">

	<h2><?php echo esc_html( get_admin_page_title() ); ?></h2>

	<h2 class="nav-tab-wrapper">Google Map Embed Options</h2>

	<form method="post" name="cleanup_options" action="options.php">

	<?php
	//Grab all options
		$options = get_option($this->plugin_name);
		// Cleanup
		$map_source = $options['map_source'];
		$map_width = $options['map_width'];
		$map_height = $options['map_height'];
	?>

	<?php
		settings_fields( $this->plugin_name );
		do_settings_sections( $this->plugin_name );
	?>

	<table>
	<!-- facebook options page -->
	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-map_source">
			<span><?php esc_attr_e('Google Map source code without quotations', $this->plugin_name);?></span></td>
			<td class="large-box"><input type="text" id="<?php echo $this->plugin_name;?>-map_source" name="<?php echo $this->plugin_name;?>[map_source]" value="<?php if(!empty($map_source)) echo $map_source;?>"/>
		</label>
	</fieldset></td></tr>
	
	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-map_width">
			<span><?php esc_attr_e('Width of map container in px', $this->plugin_name);?></span></td>
			<td class="small-box"><input type="text" id="<?php echo $this->plugin_name;?>-map_width" name="<?php echo $this->plugin_name;?>[map_width]" value="<?php if(!empty($map_width)) echo $map_width;?>"/>
		</label>
	</fieldset></td></tr>
	
	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-map_height">
			<span><?php esc_attr_e('Height of map container in px', $this->plugin_name);?></span></td>
			<td class="small-box"><input type="text" id="<?php echo $this->plugin_name;?>-map_height" name="<?php echo $this->plugin_name;?>[map_height]" value="<?php if(!empty($map_height)) echo $map_height;?>"/>
		</label>
	</fieldset></td></tr>
	</table>

    <?php submit_button('Save all changes', 'primary','submit', TRUE); ?>

    </form>
	<p>
	<?php echo "Use [psone-maps] to display on page." ?>
	</p>
