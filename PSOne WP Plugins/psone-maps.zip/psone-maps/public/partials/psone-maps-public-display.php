<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       psone.ca
 * @since      1.0.0
 *
 * @package    Psone_Maps
 * @subpackage Psone_Maps/public/partials
 */

add_shortcode('psone-maps', 'psone_maps_code');

function psone_maps_code() {

	$options = get_option('psone-maps'); ?>

	<div id="psone-map-embed">
		<iframe id="psone-map" src="<?php echo $options['map_source'] ?>" width="<?php echo $options['map_width'] ?>" height="<?php echo $options['map_height'] ?>" frameborder="0" style="border:0" allowfullscreen></iframe>
	</div>

<?php }
?>
