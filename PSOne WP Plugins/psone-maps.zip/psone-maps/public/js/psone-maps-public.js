jQuery(document).ready(function($) {

  // Enable the pointer events only on click;

  $('#psone-map').addClass('map-scrolloff'); // set the pointer events to none on doc ready
  $('#psone-map-embed').on('click', function () {
      $('#psone-map').removeClass('map-scrolloff'); // set the pointer events true on click
  });

  //Disable pointer events when the mouse leave the canvas area;
  $("#psone-map").mouseleave(function () {
    $('#psone-map').addClass('map-scrolloff'); // set the pointer events to none when mouse leaves the map area
  });

});