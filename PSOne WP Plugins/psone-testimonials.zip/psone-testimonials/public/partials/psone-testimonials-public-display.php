<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       psone.ca
 * @since      1.0.0
 *
 * @package    Psone_Testimonials
 * @subpackage Psone_Testimonials/public/partials
 */


add_shortcode('psone-testimonials', 'testimonials_slider');

function testimonials_slider() { ?>
	<?php $options = get_option('psone-testimonials'); ?>
	<section id="testimonial-slider">
		<div class="flexslider testimonial-slider">
			<ul class="slides">
				<?php $loop = new WP_Query( array( 'post_type' => 'psone-testimonials', 'posts_per_page' => 10, 'orderby' => 'menu_order', 'order' => 'ASC' ) );
				while ( $loop->have_posts() ) : $loop->the_post();
					echo '<li class="slide">';
					if ($options['quotations'] == true) {
						echo '<p class="testimonial-body"><span>"</span>'.get_the_content().'<span>"</span></p>';
					} else {
						echo '<p class="testimonial-body">'.get_the_content().'</p>';
					}
					$name = get_post_meta( get_the_ID(), '_psone-testimonials_name', true );
					$company = get_post_meta( get_the_ID(), '_psone-testimonials_company', true );
					if ( $name != '' ) {
						echo '<div class="testimonial-name">';
						if ($options['details_prefix'] != '' ) {
							echo '<span class="testimonial-name-prefix">';
							echo $options['details_prefix'];
							echo '</span>';
						}
						echo $name;
						echo '</div>';
						if (!empty($name) && !empty($company) && ($options['details_separator'] != '')) {
							echo '<span class="testimonial-name-separator">';
							echo $options['details_separator'];
							echo '</span>';
						}
					}
					if ( $company != '' ) {
						echo '<div class="testimonial-company">';
						echo $company;
						echo '</div>';
					}
					echo '</li>';
				endwhile; ?>
			</ul>
		</div>
	</section><?php
}

?>