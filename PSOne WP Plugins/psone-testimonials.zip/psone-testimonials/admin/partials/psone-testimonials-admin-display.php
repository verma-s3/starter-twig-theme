<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       psone.ca
 * @since      1.0.0
 *
 * @package    Psone_Testimonials
 * @subpackage Psone_Testimonials/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div class="wrap">

	<h2><?php echo esc_html( get_admin_page_title() ); ?></h2>

	<h2 class="nav-tab-wrapper">Display Options</h2>

	<form method="post" name="cleanup_options" action="options.php">

	<?php
	//Grab all options
		$options = get_option($this->plugin_name);
		// Cleanup
		$details_prefix = $options['details_prefix'];
		$details_separator = $options['details_separator'];
		$quotations = $options['quotations'];
		$animation_style = $options['animation_style'];
		$animation_speed = $options['animation_speed'];
		$slideshow_speed = $options['slideshow_speed'];
		$animation_loop = $options['animation_loop'];
		$pause_on_action = $options['pause_on_action'];
		$pause_on_hover = $options['pause_on_hover'];
		$control_nav = $options['control_nav'];
		$direction_nav = $options['direction_nav'];
		$randomize = $options['randomize'];
		$reverse = $options['reverse'];
		$touch = $options['touch'];
		$pause_play = $options['pause_play'];
		$smooth_height = $options['smooth_height'];
		$set_defaults = $options['set_defaults'];
	
		if ($set_defaults == 'true') {
			$animation_style = '"slide"';
			$animation_speed = 600;
			$slideshow_speed = 7000;
			$animation_loop = 'true';
			$pause_on_action = 'true';
			$pause_on_hover = 'false';
			$control_nav = 'true';
			$direction_nav = 'true';
			$randomize = 'false';
			$reverse = 'false';
			$touch = 'true';
			$pause_play = 'false';
			$smooth_height = 'false';
			$set_defaults = 'false';
		}
	
	?>

	<?php
		settings_fields( $this->plugin_name );
		do_settings_sections( $this->plugin_name );
	?>

	<table>

	<!-- Testimonial display options -->
	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-details_prefix">
			<span><?php esc_attr_e('Prefix for Name/Company', $this->plugin_name);?></span></td>
			<td><input type="text" id="<?php echo $this->plugin_name;?>-details_prefix" name="<?php echo $this->plugin_name;?>[details_prefix]" value="<?php if(!empty($details_prefix)) echo $details_prefix;?>"/>
		</label>
	</fieldset></td></tr>
	
	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-details_separator">
			<span><?php esc_attr_e('Separator for Name/Company', $this->plugin_name);?></span></td>
			<td><input type="text" id="<?php echo $this->plugin_name;?>-details_separator" name="<?php echo $this->plugin_name;?>[details_separator]" value="<?php if(!empty($details_separator)) echo $details_separator;?>"/>
		</label>
	</fieldset></td></tr>
	
	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-quotations">
			<span><?php esc_attr_e('Add quotations around testimony', $this->plugin_name);?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-quotations" name="<?php echo $this->plugin_name;?>[quotations]" value="1" <?php checked( $quotations, 1 ); ?> />
		</label>
	</fieldset></td></tr>
	</table>
	
	
	<h2 class="nav-tab-wrapper">Slider Options</h2>
	
	<table>

	<!-- Testimonial slider options -->
	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-animation_speed">
			<span><?php esc_attr_e('Set the speed of animations, in milliseconds', $this->plugin_name);?></span></td>
			<td><input type="text" id="<?php echo $this->plugin_name;?>-animation_speed" name="<?php echo $this->plugin_name;?>[animation_speed]" value="<?php if(!empty($animation_speed)) echo $animation_speed;?>"/>
		</label>
	</fieldset></td></tr>
	
	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-slideshow_speed">
			<span><?php esc_attr_e('Set the speed of the slideshow cycling, in milliseconds', $this->plugin_name);?></span></td>
			<td><input type="text" id="<?php echo $this->plugin_name;?>-slideshow_speed" name="<?php echo $this->plugin_name;?>[slideshow_speed]" value="<?php if(!empty($slideshow_speed)) echo $slideshow_speed;?>"/>
		</label>
	</fieldset></td></tr>

	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-animation_style">
			<span><?php esc_attr_e( 'Controls the animation type', $this->plugin_name ); ?></span></td>
			<td><select id="<?php echo $this->plugin_name;?>-animation_style" name="<?php echo $this->plugin_name;?>[animation_style]" value="<?php echo $animation_style;?>">
			<option value='"slide"'<?php if($options['animation_style'] == '"slide"'){ echo ' selected="selected"'; } ?>>Slide</option>
			<option value='"fade"'<?php if($options['animation_style'] == '"fade"'){ echo ' selected="selected"'; } ?>>Fade</option>
			</select>
		</label>
	</fieldset></td></tr>

	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-direction_nav">
			<span><?php esc_attr_e( 'Enable previous/next arrow navigation', $this->plugin_name ); ?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-direction_nav" name="<?php echo $this->plugin_name;?>[direction_nav]" value="1" <?php checked( $direction_nav, 'true' ); ?> />
		</label>
	</fieldset></td></tr>

	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-animation_loop">
			<span><?php esc_attr_e( 'Infinite loop', $this->plugin_name ); ?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-animation_loop" name="<?php echo $this->plugin_name;?>[animation_loop]" value="1" <?php checked( $animation_loop, 'true' ); ?> />
		</label>
	</fieldset></td></tr>

	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-pause_on_action">
			<span><?php esc_attr_e( 'Pause the slideshow when interacting with control elements', $this->plugin_name ); ?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-pause_on_action" name="<?php echo $this->plugin_name;?>[pause_on_action]" value="1" <?php checked( $pause_on_action, 'true' ); ?> />
		</label>
	</fieldset></td></tr>

	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-pause_on_hover">
			<span><?php esc_attr_e( 'Pause the slideshow when hovering over slider, then resume when no longer hovering', $this->plugin_name ); ?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-pause_on_hover" name="<?php echo $this->plugin_name;?>[pause_on_hover]" value="1" <?php checked( $pause_on_hover, 'true' ); ?> />
		</label>
	</fieldset></td></tr>

	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-control_nav">
			<span><?php esc_attr_e( 'Create navigation for paging control of each slide', $this->plugin_name ); ?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-control_nav" name="<?php echo $this->plugin_name;?>[control_nav]" value="1" <?php checked( $control_nav, 'true' ); ?> />
		</label>
	</fieldset></td></tr>

	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-randomize">
			<span><?php esc_attr_e( 'Randomize slide order, on load', $this->plugin_name ); ?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-randomize" name="<?php echo $this->plugin_name;?>[randomize]" value="1" <?php checked( $randomize, 'true' ); ?> />
		</label>
	</fieldset></td></tr>

	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-reverse">
			<span><?php esc_attr_e( 'Reverse the animation direction', $this->plugin_name ); ?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-reverse" name="<?php echo $this->plugin_name;?>[reverse]" value="1" <?php checked( $reverse, 'true' ); ?> />
		</label>
	</fieldset></td></tr>

	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-touch">
			<span><?php esc_attr_e( 'Allow touch swipe navigation of the slider on enabled devices', $this->plugin_name ); ?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-touch" name="<?php echo $this->plugin_name;?>[touch]" value="1" <?php checked( $touch, 'true' ); ?> />
		</label>
	</fieldset></td></tr>

	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-pause_play">
			<span><?php esc_attr_e( 'Create pause/play element to control slider slideshow', $this->plugin_name ); ?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-pause_play" name="<?php echo $this->plugin_name;?>[pause_play]" value="1" <?php checked( $pause_play, 'true' ); ?> />
		</label>
	</fieldset></td></tr>

	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-smooth_height">
			<span><?php esc_attr_e( 'Animate the height of the slider smoothly for slides of varying height', $this->plugin_name ); ?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-smooth_height" name="<?php echo $this->plugin_name;?>[smooth_height]" value="1" <?php checked( $smooth_height, 'true' ); ?> />
		</label>
	</fieldset></td></tr>
	</table>
	
	<h2 class="nav-tab-wrapper">Defaults</h2>
	
	<table>

	<!-- Testimonial slider options -->
	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-set_defaults">
			<span><?php esc_attr_e( 'Set/Reset ALL slider options to defaults', $this->plugin_name ); ?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-set_defaults" name="<?php echo $this->plugin_name;?>[set_defaults]" value="1" <?php checked( $set_defaults, 'true' ); ?> />
		</label>
	</fieldset></td></tr>
	</table>

    <?php submit_button('Save all changes', 'primary','submit', TRUE); ?>

    </form>
	<p>
	<?php echo "Use [psone-testimonials] to display on page."; ?>
	</p>
