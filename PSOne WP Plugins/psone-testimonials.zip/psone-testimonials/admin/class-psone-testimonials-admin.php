<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       psone.ca
 * @since      1.0.0
 *
 * @package    Psone_Testimonials
 * @subpackage Psone_Testimonials/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Psone_Testimonials
 * @subpackage Psone_Testimonials/admin
 * @author     Print Studio One <it@psone.ca>
 */
class Psone_Testimonials_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;
	
		function psone_testimonials_setup() {
			$labels = array(
				'name' => __( 'Testimonials', 'psone-testimonials' ),
				'singular_name' => __( 'Testimonial', 'psone-testimonials' ),
				'add_new_item' => __( 'Add New', 'psone-testimonials' ),
				'edit_item' => __( 'Edit', 'psone-testimonials' ),
				'new_item' => __( 'New', 'psone-testimonials' ),
				'not_found' => __( 'No Testimonial found', 'psone-testimonials' ),
				'all_items' => __( 'All Testimonies', 'psone-testimonials' )
			);
			$args = array(
				'labels' => $labels,
				'public' => true,
				'show_ui' => true,
				'show_in_menu' => true,
				'has_archive' => true,
				'map_meta_cap' => true,
				'menu_icon' => 'dashicons-format-chat',		
				'supports' => array( 'title', 'editor', 'author', 'page-attributes' )
			);
			register_post_type( 'psone-testimonials', $args );
		}
		add_action( 'init', 'psone_testimonials_setup' );
		
		function psone_testimonials_add_meta_boxes( $post ){
			add_meta_box( 'psone_testimonials_meta_box', __( 'Testimonial Details', 'psone-testimonials' ), 'psone_testimonials_build_meta_box', 'psone-testimonials', 'normal', 'high' );
		}
		
		function psone_testimonials_build_meta_box( $post ){
			// make sure the form request comes from WordPress
			wp_nonce_field( basename( __FILE__ ), 'psone_testimonials_meta_box_nonce' );
			// retrieve the _testimonial_name current value
			$current_name = get_post_meta( $post->ID, '_psone-testimonials_name', true );
			// retrieve the _testimonial_company current value
			$current_company = get_post_meta( $post->ID, '_psone-testimonials_company', true );
			?>
			<div class='inside'>

				<h3><?php _e( 'Name', 'psone-testimonials' ); ?></h3>
				<p>
					<input type="text" name="name" value="<?php echo $current_name; ?>" />
				</p>

				<h3><?php _e( 'Company', 'psone-testimonials' ); ?></h3>
				<p>
					<input type="text" name="company" value="<?php echo $current_company; ?>" /> 
				</p>
			</div>
			<?php
		}
		
		add_action( 'add_meta_boxes_psone-testimonials', 'psone_testimonials_add_meta_boxes' );
	
		function psone_testimonials_save_meta_box_data( $post_id ){
			// verify meta box nonce
			if ( !isset( $_POST['psone_testimonials_meta_box_nonce'] ) || !wp_verify_nonce( $_POST['psone_testimonials_meta_box_nonce'], basename( __FILE__ ) ) ){
				return;
			}
			// return if autosave
			if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ){
				return;
			}
		  // Check the user's permissions.
			if ( ! current_user_can( 'edit_post', $post_id ) ){
				return;
			}
			// store custom fields values
			// name string
			if ( isset( $_REQUEST['name'] ) ) {
				update_post_meta( $post_id, '_psone-testimonials_name', sanitize_text_field( $_POST['name'] ) );
			}
			// store custom fields values
			// company string
			if ( isset( $_REQUEST['company'] ) ) {
				update_post_meta( $post_id, '_psone-testimonials_company', sanitize_text_field( $_POST['company'] ) );
			}
			// store custom fields values
			// options array
			if( isset( $_POST['options'] ) ){
				$options = (array) $_POST['options'];
				// sinitize array
				$options = array_map( 'sanitize_text_field', $options );
				// save data
				update_post_meta( $post_id, '_psone-testimonials_options', $options );
			}else{
				// delete data
				delete_post_meta( $post_id, '_psone-testimonials_options' );
			}
		}
		add_action( 'save_post_psone-testimonials', 'psone_testimonials_save_meta_box_data' );

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Psone_Testimonials_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Psone_Testimonials_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/psone-testimonials-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Psone_Testimonials_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Psone_Testimonials_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		//wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/psone-testimonials-admin.js', array( 'jquery' ), $this->version, false );

	}
	/**
	 * Register the administration menu for this plugin into the WordPress Dashboard menu.
	 *
	 * @since    1.0.0
	 */
	 
	public function add_plugin_admin_menu() {

		/*
		 * Add a settings page for this plugin to the Settings menu.
		 *
		 * NOTE:  Alternative menu locations are available via WordPress administration menu functions.
		 *
		 *        Administration Menus: http://codex.wordpress.org/Administration_Menus
		 *
		 */
		
		//add_submenu_page('edit.php?post_type=', 'Testimonial Settings', 'Settings', 'edit_posts', 'settings_function');
		add_options_page( 'Testimonial Slider Settings', 'Testimonials Settings', 'manage_options', $this->plugin_name, array($this, 'display_plugin_setup_page')
    );
	}

	 /**
	 * Add settings action link to the plugins page.
	 *
	 * @since    1.0.0
	 */
	 
	public function add_action_links( $links ) {
		/*
		*  Documentation : https://codex.wordpress.org/Plugin_API/Filter_Reference/plugin_action_links_(plugin_file_name)
		*/
	   $settings_link = array(
		'<a href="' . admin_url( 'options-general.php?page=' . $this->plugin_name ) . '">' . __('Settings', $this->plugin_name) . '</a>',
	   );
	   return array_merge(  $settings_link, $links );

	}

	/**
	 * Render the settings page for this plugin.
	 *
	 * @since    1.0.0
	 */
		function settings_function() { ?>
			
		<?php }
	 
	public function display_plugin_setup_page() {
		include_once( 'partials/psone-testimonials-admin-display.php' );
	}

	public function options_update() {
		register_setting($this->plugin_name, $this->plugin_name, array($this, 'validate'));
	}
	
	public function validate($input) {
		// All checkboxes inputs
		$valid = array();

		//Cleanup
		$valid['details_prefix'] = ($input['details_prefix']);
		$valid['details_separator'] = ($input['details_separator']);
		$valid['quotations'] = ($input['quotations']);
		$valid['animation_style'] = ($input['animation_style']);
		$valid['animation_speed'] = ($input['animation_speed']);
		$valid['slideshow_speed'] = ($input['slideshow_speed']);
		$valid['direction'] = ($input['direction']);
		$valid['direction_nav'] = (isset($input['direction_nav']) && !empty($input['direction_nav'])) ? 'true' : 'false';
		$valid['pause_on_hover'] = (isset($input['pause_on_hover']) && !empty($input['pause_on_hover'])) ? 'true' : 'false';
		$valid['animation_loop'] = (isset($input['animation_loop']) && !empty($input['animation_loop'])) ? 'true' : 'false';
		$valid['pause_on_action'] = (isset($input['pause_on_action']) && !empty($input['pause_on_action'])) ? 'true' : 'false';
		$valid['control_nav'] = (isset($input['control_nav']) && !empty($input['control_nav'])) ? 'true' : 'false';
		$valid['randomize'] = (isset($input['randomize']) && !empty($input['randomize'])) ? 'true' : 'false';
		$valid['reverse'] = (isset($input['reverse']) && !empty($input['reverse'])) ? 'true' : 'false';
		$valid['touch'] = (isset($input['touch']) && !empty($input['touch'])) ? 'true' : 'false';
		$valid['pause_play'] = (isset($input['pause_play']) && !empty($input['pause_play'])) ? 'true' : 'false';
		$valid['set_defaults'] = (isset($input['set_defaults']) && !empty($input['set_defaults'])) ? 'true' : 'false';
		$valid['smooth_height'] = (isset($input['smooth_height']) && !empty($input['smooth_height'])) ? 'true' : 'false';
		
		return $valid;
	}

}