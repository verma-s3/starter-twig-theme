<?php

/**
 * Fired during plugin deactivation
 *
 * @link       psone.ca
 * @since      1.0.0
 *
 * @package    Psone_Testimonials
 * @subpackage Psone_Testimonials/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Psone_Testimonials
 * @subpackage Psone_Testimonials/includes
 * @author     Print Studio One <it@psone.ca>
 */
class Psone_Testimonials_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
