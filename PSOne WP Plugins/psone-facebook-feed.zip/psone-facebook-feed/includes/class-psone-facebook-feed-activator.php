<?php

/**
 * Fired during plugin activation
 *
 * @link       psone.ca
 * @since      1.0.0
 *
 * @package    Psone_Facebook_Feed
 * @subpackage Psone_Facebook_Feed/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Psone_Facebook_Feed
 * @subpackage Psone_Facebook_Feed/includes
 * @author     Print Studio One <it@psone.ca>
 */
class Psone_Facebook_Feed_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
