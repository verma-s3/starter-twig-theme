<?php

/**
 * Define the internationalization functionality
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       psone.ca
 * @since      1.0.0
 *
 * @package    Psone_Facebook_Feed
 * @subpackage Psone_Facebook_Feed/includes
 */

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      1.0.0
 * @package    Psone_Facebook_Feed
 * @subpackage Psone_Facebook_Feed/includes
 * @author     Print Studio One <it@psone.ca>
 */
class Psone_Facebook_Feed_i18n {


	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'psone-facebook-feed',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}



}
