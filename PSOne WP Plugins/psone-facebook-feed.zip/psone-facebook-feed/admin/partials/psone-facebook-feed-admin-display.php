<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       psone.ca
 * @since      1.0.0
 *
 * @package    Psone_Facebook_Feed
 * @subpackage Psone_Facebook_Feed/admin/partials
 */
?>


<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div class="wrap">

	<h2><?php echo esc_html( get_admin_page_title() ); ?></h2>

	<h2 class="nav-tab-wrapper">Display Options</h2>

	<form method="post" name="cleanup_options" action="options.php">

	<?php
	//Grab all options
		$options = get_option($this->plugin_name);
		// Cleanup
		$fb_hide_cover = $options['fb_hide_cover'];
		$fb_small_header = $options['fb_small_header'];
		$fb_show_friends = $options['fb_show_friends'];
		$fb_adapt_width = $options['fb_adapt_width'];
		$fb_width = $options['fb_width'];
		$fb_height = $options['fb_height'];
		$fb_tabs = $options['fb_tabs'];
		$fb_url = $options['fb_url'];
	?>

	<?php
		settings_fields( $this->plugin_name );
		do_settings_sections( $this->plugin_name );
	?>

	<table style="margin-top:20px">
	<!-- facebook options page -->
	<tr><td><fieldset>
		<legend class="screen-reader-text"><span>Hide Cover Photo</span></legend>
		<label for="<?php echo $this->plugin_name;?>-fb_hide_cover">
			<span><?php esc_attr_e( 'Hide Cover Photo', $this->plugin_name ); ?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-fb_hide_cover" name="<?php echo $this->plugin_name;?>[fb_hide_cover]" value="1" <?php checked( $fb_hide_cover, 1 ); ?> />
		</label>
	</fieldset></td></tr>

	<!-- facebook options page -->
	<tr><td><fieldset>
		<legend class="screen-reader-text"><span>Use Small Header</span></legend>
		<label for="<?php echo $this->plugin_name;?>-fb_small_header">
			<span><?php esc_attr_e( 'Use Small Header', $this->plugin_name ); ?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-fb_small_header" name="<?php echo $this->plugin_name;?>[fb_small_header]" value="1" <?php checked( $fb_small_header, 1 ); ?> />
		</label>
	</fieldset></td></tr>

	<!-- facebook options page -->
	<tr><td><fieldset>
		<legend class="screen-reader-text"><span>Show Friends Faces</span></legend>
		<label for="<?php echo $this->plugin_name;?>-fb_show_friends">
			<span><?php esc_attr_e( 'Show Friends Faces', $this->plugin_name ); ?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-fb_show_friends" name="<?php echo $this->plugin_name;?>[fb_show_friends]" value="1" <?php checked( $fb_show_friends, 1 ); ?>  />
		</label></td></tr>
	</fieldset>

	<!-- facebook options page -->
	<tr><td><fieldset>
		<legend class="screen-reader-text"><span>Adapt to container width</span></legend>
		<label for="<?php echo $this->plugin_name;?>-fb_adapt_width">
			<span><?php esc_attr_e('Adapt to container width', $this->plugin_name);?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-fb_adapt_width" name="<?php echo $this->plugin_name;?>[fb_adapt_width]" value="1" <?php checked( $fb_adapt_width, 1 ); ?>  />
		</label>
	</fieldset></td></tr>

	<!-- facebook options page -->
	<tr><td><fieldset>
		<legend class="screen-reader-text"><span>The pixel width of the plugin. Min is 180 and Max is 500</span></legend>
		<label for="<?php echo $this->plugin_name;?>-fb_width">
			<span><?php esc_attr_e('The pixel width of the plugin. Min is 180 and Max is 500', $this->plugin_name);?></span></td>
			<td><input type="text" id="<?php echo $this->plugin_name;?>-fb_width" name="<?php echo $this->plugin_name;?>[fb_width]" value="<?php if(!empty($fb_width)) echo $fb_width;?>"/>
		</label>
	</fieldset></td></tr>

	<!-- facebook options page -->
	<tr><td><fieldset>
		<legend class="screen-reader-text"><span>The pixel height of the plugin. Min is 70</span></legend>
		<label for="<?php echo $this->plugin_name;?>-fb_height">
			<span><?php esc_attr_e('The pixel height of the plugin. Min is 70', $this->plugin_name);?></span></td>
			<td><input type="text" id="<?php echo $this->plugin_name;?>-fb_height" name="<?php echo $this->plugin_name;?>[fb_height]" value="<?php if(!empty($fb_height)) echo $fb_height;?>"/>
		</label>
	</fieldset></td></tr>

	<!-- facebook options page -->
	<tr><td><fieldset>
		<legend class="screen-reader-text"><span>Tabs to show, separated with comma (timeline, events, messages)</span></legend>
		<label for="<?php echo $this->plugin_name;?>-fb_tabs">
			<span><?php esc_attr_e('Tabs to show, separated with comma (timeline, events, messages)', $this->plugin_name);?></span></td>
			<td><input type="text" id="<?php echo $this->plugin_name;?>-fb_tabs" name="<?php echo $this->plugin_name;?>[fb_tabs]" value="<?php if(!empty($fb_tabs)) echo $fb_tabs;?>"/>
		</label>
	</fieldset></td></tr>

	<!-- facebook options page -->
	<tr><td><fieldset>
		<legend class="screen-reader-text"><span>The url of the facebook page, https://facebook.com/</span></legend>
		<label for="<?php echo $this->plugin_name;?>-fb_url">
			<span><?php esc_attr_e('The url of the facebook page, https://facebook.com/', $this->plugin_name);?></span></td>
			<td><input type="text" id="<?php echo $this->plugin_name;?>-fb_url" name="<?php echo $this->plugin_name;?>[fb_url]" value="<?php if(!empty($fb_url)) echo $fb_url;?>"/>
		</label>
	</fieldset></td></tr>
	</table>



            <?php submit_button('Save all changes', 'primary','submit', TRUE); ?>

    </form>
	<p>
	<?php 
	$shortcode_value = '[psone-facebook-feed';
	if ($fb_width != '') {
		$shortcode_value .= ' width="' . $fb_width . '"';
	}
	if ($fb_height != '') {
		$shortcode_value .= ' height="' . $fb_height . '"';
	}
	if ($fb_small_header != '') {
		$shortcode_value .= ' header="true"';
	} else {
		$shortcode_value .= ' header="false"';
	};
	if ($fb_show_friends != '') {
		$shortcode_value .= ' friends="true"';
	} else {
		$shortcode_value .= ' friends="false"';
	};
	if ($fb_adapt_width != '') {
		$shortcode_value .= ' adwidth="true"';
	} else {
		$shortcode_value .= ' adwidth="false"';
	};
	if ($fb_hide_cover != '') {
		$shortcode_value .= ' cover="true"';
	} else {
		$shortcode_value .= ' cover="false"';
	};
	if ($fb_tabs != '') {
		$shortcode_value .= ' tabs="' . $fb_tabs . '"';
	}
	if ($fb_url != '') {
		$shortcode_value .= ' url="' . $fb_url . '"';
	}
	echo "Use this shortcode to display on page:"; ?>
	</p><p>
	<?php echo $shortcode_value . "]"; ?>
	</p>


