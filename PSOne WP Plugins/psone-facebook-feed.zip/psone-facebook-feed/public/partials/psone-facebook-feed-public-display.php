<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       psone.ca
 * @since      1.0.0
 *
 * @package    Psone_Facebook_Feed
 * @subpackage Psone_Facebook_Feed/public/partials
 */
 
//facebook feed shortcode

add_shortcode('psone-facebook-feed', 'facebook_feed_code');

function facebook_feed_code($fboptions) { 
extract(shortcode_atts(array('width' => '','height' => '','url' => '','header' => '','friends' => '', 'adwidth' => '','tabs' => '','cover' => ''), $fboptions));
?>

<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.6";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<div class="fb-page" 
data-href="https://www.facebook.com/<?php echo $fboptions['url'] ?>" 
data-tabs="<?php echo $fboptions['tabs'] ?>" 
data-width="<?php echo $fboptions['width'] ?>" 
data-height="<?php echo $fboptions['height'] ?>" 
data-small-header="<?php echo $fboptions['header'] ?>" 
data-adapt-container-width="<?php echo $fboptions['adwidth'] ?>" 
data-hide-cover="<?php echo $fboptions['cover'] ?>" 
data-show-facepile="<?php echo $fboptions['friends'] ?>">
<blockquote cite="https://www.facebook.com/<?php echo $fboptions['url'] ?>" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/<?php echo $fboptions['url'] ?>">Facebook</a>
</blockquote>
</div>
</div>

<?php }
?>
