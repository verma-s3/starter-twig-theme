<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       http://psone.ca
 * @since      1.0.0
 *
 * @package    Psone_Slider
 * @subpackage Psone_Slider/public/partials
 */


add_shortcode('psone-slider', 'psoslider_slider');

function psoslider_slider() { ?>
	<?php $options = get_option('psone-slider'); ?>
	<?php $loop = new WP_Query( array( 'post_type' => 'psone-slider', 'posts_per_page' => 10, 'orderby' => 'menu_order', 'order' => 'ASC' ) );
	if ( $loop->have_posts() ) : $loop->the_post();
		$image_id = get_post_meta( get_the_ID(), '_psone-slider_image_id', true );
		$image_src = wp_get_attachment_url( $image_id );
		$text_position = get_post_meta( get_the_ID(), '_psone-slider_text-position', true );
		$output_title = get_post_meta( get_the_ID(), '_psone-slider_output-title', true );
	endif; ?>
	<div class="psoneslider-first-slide">
		<img src="<?php echo $image_src ?>" alt="<?php the_title() ?>" />
	</div>
	
	<section id="psone-slider" style="display: none">
		<div class="flexslider pso-slider">
			<ul class="slides">
				<?php //Render first slide
				if ($image_id != '') { ?>
					<li class="slide">
					<img src="<?php echo $image_src ?>" alt="<?php the_title() ?>" /> <?php
					if ($text_position == '"center"') {
						echo '<div class="slider-content"> <div class="container"> <div class="row pso-slider-center">';
						if (($options['display_title'] == 'true') && ($options['display_output_title'] == 'true')) {
							echo '<h1>' .  $output_title . '</h1><br>';
						}else if (($options['display_title'] == 'true') && ($options['display_output_title'] == 'false')) { ?>
							<h1><?php echo the_title(); ?></h1><br><?php
						}
						if ($options['display_body'] == 'true') {
							echo the_content();
						}
						echo '</div></div></div>';
					}else if ($text_position == '"top-left"') {
						echo '<div class="slider-content"> <div class="container"> <div class="row pso-slider-top-left">';
						if (($options['display_title'] == 'true') && ($options['display_output_title'] == 'true')) {
							echo '<h1>' .  $output_title . '</h1><br>';
						}else if (($options['display_title'] == 'true') && ($options['display_output_title'] == 'false')) { ?>
							<h1><?php echo the_title(); ?></h1><br><?php
						}
						if ($options['display_body'] == 'true') {
							echo the_content();
						}
						echo '</div></div></div>';
					}else if ($text_position == '"top-right"') {
						echo '<div class="slider-content"> <div class="container"> <div class="row pso-slider-top-right">';
						if (($options['display_title'] == 'true') && ($options['display_output_title'] == 'true')) {
							echo '<h1>' .  $output_title . '</h1><br>';
						}else if (($options['display_title'] == 'true') && ($options['display_output_title'] == 'false')) { ?>
							<h1><?php echo the_title(); ?></h1><br><?php
						}
						if ($options['display_body'] == 'true') {
							echo the_content();
						}
						echo '</div></div></div>';
					}else if ($text_position == '"bottom"') {
						echo '<div class="slider-content"> <div class="container"> <div class="row pso-slider-bottom">';
						if (($options['display_title'] == 'true') && ($options['display_output_title'] == 'true')) {
							echo '<h1>' .  $output_title . '</h1><br>';
						}else if (($options['display_title'] == 'true') && ($options['display_output_title'] == 'false')) { ?>
							<h1><?php echo the_title(); ?></h1><br><?php
						}
						if ($options['display_body'] == 'true') {
							echo the_content();
						}
						echo '</div></div></div>';
					}else if ($text_position == '"bottom-left"') {
						echo '<div class="slider-content"> <div class="container"> <div class="row pso-slider-bottom-left">';
						if (($options['display_title'] == 'true') && ($options['display_output_title'] == 'true')) {
							echo '<h1>' .  $output_title . '</h1><br>';
						}else if (($options['display_title'] == 'true') && ($options['display_output_title'] == 'false')) { ?>
							<h1><?php echo the_title(); ?></h1><br><?php
						}
						if ($options['display_body'] == 'true') {
							echo the_content();
						}
						echo '</div></div></div>';
					}else if ($text_position == '"bottom-right"') {
						echo '<div class="slider-content"> <div class="container"> <div class="row pso-slider-bottom-right">';
						if (($options['display_title'] == 'true') && ($options['display_output_title'] == 'true')) {
							echo '<h1>' .  $output_title . '</h1><br>';
						}else if (($options['display_title'] == 'true') && ($options['display_output_title'] == 'false')) { ?>
							<h1><?php echo the_title(); ?></h1><br><?php
						}
						if ($options['display_body'] == 'true') {
							echo the_content();
						}
						echo '</div></div></div>';
					}else if (($options['display_title'] == 'true') || ($options['display_body'] == 'true')) {
						echo '<div class="slider-content"> <div class="container"> <div class="row">';
						if (($options['display_title'] == 'true') && ($options['display_output_title'] == 'true')) {
							echo '<h1>' .  $output_title . '</h1><br>';
						}else if (($options['display_title'] == 'true') && ($options['display_output_title'] == 'false')) { ?>
							<h1><?php echo the_title(); ?></h1><br><?php
						}
						if ($options['display_body'] == 'true') {
							echo the_content();
						}
						echo '</div></div></div>';
					} ?>
					</li> <?php
				}
				//Render slider
				while ( $loop->have_posts() ) : $loop->the_post();
					$image_id = get_post_meta( get_the_ID(), '_psone-slider_image_id', true );
					$image_src = wp_get_attachment_url( $image_id );
					$text_position = get_post_meta( get_the_ID(), '_psone-slider_text-position', true );
					$output_title = get_post_meta( get_the_ID(), '_psone-slider_output-title', true );
					
					if ($image_id != '') { ?>
						<li class="slide">
						<img src="<?php echo $image_src ?>" alt="<?php the_title() ?>" /> <?php
						if ($text_position == '"center"') {
							echo '<div class="slider-content"> <div class="container"> <div class="row pso-slider-center">';
							if (($options['display_title'] == 'true') && ($options['display_output_title'] == 'true')) {
								echo '<h1>' .  $output_title . '</h1><br>';
							}else if (($options['display_title'] == 'true') && ($options['display_output_title'] == 'false')) { ?>
								<h1><?php echo the_title(); ?></h1><br><?php
							}
							if ($options['display_body'] == 'true') {
								echo the_content();
							}
							echo '</div></div></div>';
						}else if ($text_position == '"top-left"') {
							echo '<div class="slider-content"> <div class="container"> <div class="row pso-slider-top-left">';
							if (($options['display_title'] == 'true') && ($options['display_output_title'] == 'true')) {
								echo '<h1>' .  $output_title . '</h1><br>';
							}else if (($options['display_title'] == 'true') && ($options['display_output_title'] == 'false')) { ?>
								<h1><?php echo the_title(); ?></h1><br><?php
							}
							if ($options['display_body'] == 'true') {
								echo the_content();
							}
							echo '</div></div></div>';
						}else if ($text_position == '"top-right"') {
							echo '<div class="slider-content"> <div class="container"> <div class="row pso-slider-top-right">';
							if (($options['display_title'] == 'true') && ($options['display_output_title'] == 'true')) {
								echo '<h1>' .  $output_title . '</h1><br>';
							}else if (($options['display_title'] == 'true') && ($options['display_output_title'] == 'false')) { ?>
								<h1><?php echo the_title(); ?></h1><br><?php
							}
							if ($options['display_body'] == 'true') {
								echo the_content();
							}
							echo '</div></div></div>';
						}else if ($text_position == '"bottom"') {
							echo '<div class="slider-content"> <div class="container"> <div class="row pso-slider-bottom">';
							if (($options['display_title'] == 'true') && ($options['display_output_title'] == 'true')) {
								echo '<h1>' .  $output_title . '</h1><br>';
							}else if (($options['display_title'] == 'true') && ($options['display_output_title'] == 'false')) { ?>
								<h1><?php echo the_title(); ?></h1><br><?php
							}
							if ($options['display_body'] == 'true') {
								echo the_content();
							}
							echo '</div></div></div>';
						}else if ($text_position == '"bottom-left"') {
							echo '<div class="slider-content"> <div class="container"> <div class="row pso-slider-bottom-left">';
							if (($options['display_title'] == 'true') && ($options['display_output_title'] == 'true')) {
								echo '<h1>' .  $output_title . '</h1><br>';
							}else if (($options['display_title'] == 'true') && ($options['display_output_title'] == 'false')) { ?>
								<h1><?php echo the_title(); ?></h1><br><?php
							}
							if ($options['display_body'] == 'true') {
								echo the_content();
							}
							echo '</div></div></div>';
						}else if ($text_position == '"bottom-right"') {
							echo '<div class="slider-content"> <div class="container"> <div class="row pso-slider-bottom-right">';
							if (($options['display_title'] == 'true') && ($options['display_output_title'] == 'true')) {
								echo '<h1>' .  $output_title . '</h1><br>';
							}else if (($options['display_title'] == 'true') && ($options['display_output_title'] == 'false')) { ?>
								<h1><?php echo the_title(); ?></h1><br><?php
							}
							if ($options['display_body'] == 'true') {
								echo the_content();
							}
							echo '</div></div></div>';
						}else if (($options['display_title'] == 'true') || ($options['display_body'] == 'true')) {
							echo '<div class="slider-content"> <div class="container"> <div class="row">';
							if (($options['display_title'] == 'true') && ($options['display_output_title'] == 'true')) {
								echo '<h1>' .  $output_title . '</h1><br>';
							}else if (($options['display_title'] == 'true') && ($options['display_output_title'] == 'false')) { ?>
								<h1><?php echo the_title(); ?></h1><br><?php
							}
							if ($options['display_body'] == 'true') {
								echo the_content();
							}
							echo '</div></div></div>';
						} ?>
						</li> <?php
					}
				endwhile; ?>
			</ul>
		</div>
	</section><?php
}

?>