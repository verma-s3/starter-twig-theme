<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       http://psone.ca
 * @since      1.0.0
 *
 * @package    Psone_Slider
 * @subpackage Psone_Slider/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Psone_Slider
 * @subpackage Psone_Slider/admin
 * @author     Print Studio One <it@psone.ca>
 */
class Psone_Slider_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;
	
		function psone_slider_setup() {
			$labels = array(
				'name' => __( 'Slider', 'psone-slider' ),
				'singular_name' => __( 'Slider', 'psone-slider' ),
				'add_new_item' => __( 'Add New', 'psone-slider' ),
				'edit_item' => __( 'Edit', 'psone-slider' ),
				'new_item' => __( 'New', 'psone-slider' ),
				'not_found' => __( 'No Slides found', 'psone-slider' ),
				'all_items' => __( 'All Slides', 'psone-slider' )
			);
			$args = array(
				'labels' => $labels,
				'public' => true,
				'show_ui' => true,
				'show_in_menu' => true,
				'has_archive' => true,
				'map_meta_cap' => true,
				'menu_icon' => 'dashicons-images-alt2',		
				'supports' => array( 'title', 'editor', 'page-attributes' )
			);
			register_post_type( 'psone-slider', $args );
		}
		add_action( 'init', 'psone_slider_setup' );
		
		function psone_slider_add_meta_boxes( $post ){
			add_meta_box( 'psone_slider_meta_box', __( 'Slider Details', 'psone-slider' ), 'psone_slider_build_meta_box', 'psone-slider', 'normal', 'high' );
		}
		
		function psone_slider_build_meta_box( $post ){
			
			//get display options
			$options = get_option('psone-slider');
			
			// make sure the form request comes from WordPress
			wp_nonce_field( basename( __FILE__ ), 'psone_slider_meta_box_nonce' );
			// retrieve the _slider_text-position current value
			$current_text_position = get_post_meta( $post->ID, '_psone-slider_text-position', true );
			$current_output_title = get_post_meta( $post->ID, '_psone-slider_output-title', true );
			
			$image_src = '';
			
			$image_id = get_post_meta( $post->ID, '_psone-slider_image_id', true );
			$image_src = wp_get_attachment_url( $image_id );
			
			?>
			<div class='inside'>
				<img id="slide_image" src="<?php echo $image_src ?>" style="max-width:25%;" />
				<input type="hidden" name="upload_image_id" id="upload_image_id" value="<?php echo $image_id; ?>" />
				<p>
					<a title="<?php esc_attr_e( 'Set slide image' ) ?>" href="#" id="set-slide-image"><?php _e( 'Set slide image' ) ?></a>
					<a title="<?php esc_attr_e( 'Remove slide image' ) ?>" href="#" id="remove-slide-image" style="<?php echo ( ! $image_id ? 'display:none;' : '' ); ?>"><?php _e( 'Remove slide image' ) ?></a>
				</p>

				<?php if (($options['display_center'] == 'true') || ($options['display_top_left'] == 'true') || ($options['display_top_right'] == 'true') || ($options['display_bottom'] == 'true') || ($options['display_bottom_left'] == 'true') || ($options['display_bottom_right'] == 'true')) { ?>
					<div id="psone-slider-select">
						<h3><?php _e( 'Text Position', 'psone-slider' ); ?></h3>
						<p>
							<select name="text-position" value="<?php echo $current_text_position; ?>">
								<?php if ($options['display_center'] == 'true') {
									?><option value='"center"'<?php if($current_text_position == '"center"'){ echo ' selected="selected"'; } ?>>Center</option>
								<?php } ?>
								<?php if ($options['display_top_left'] == 'true') {
									?><option value='"top-left"'<?php if($current_text_position == '"top-left"'){ echo ' selected="selected"'; } ?>>Top Left</option>
								<?php } ?>
								<?php if ($options['display_top_right'] == 'true') {
									?><option value='"top-right"'<?php if($current_text_position == '"top-right"'){ echo ' selected="selected"'; } ?>>Top Right</option>
								<?php } ?>
								<?php if ($options['display_bottom'] == 'true') {
									?><option value='"bottom"'<?php if($current_text_position == '"bottom"'){ echo ' selected="selected"'; } ?>>Bottom</option>
								<?php } ?>
								<?php if ($options['display_bottom_left'] == 'true') {
									?><option value='"bottom-left"'<?php if($current_text_position == '"bottom-left"'){ echo ' selected="selected"'; } ?>>Bottom Left</option>
								<?php } ?>
								<?php if ($options['display_bottom_right'] == 'true') {
									?><option value='"bottom-right"'<?php if($current_text_position == '"bottom-right"'){ echo ' selected="selected"'; } ?>>Bottom Right</option>
								<?php } ?>
							</select>
						</p>
					</div>
				<?php } ?>
				<?php if ($options['display_output_title'] == 'true') { ?>
					<div id="psone-slider-fields">
						<h3><?php _e( 'Display Title', 'psone-slider' ); ?></h3>
						<p><input type="text" name="output-title" value="<?php echo $current_output_title; ?>" /></p>
					</div>
				<?php } ?>
		
		<script type="text/javascript">
		jQuery(document).ready(function($) {
			
			// save the send_to_editor handler function
			window.send_to_editor_default = window.send_to_editor;
	
			$('#set-slide-image').click(function(){
				
				// replace the default send_to_editor handler function with our own
				window.send_to_editor = window.attach_image;
				tb_show('', 'media-upload.php?post_id=<?php echo $post->ID ?>&amp;type=image&amp;TB_iframe=true');
				
				return false;
			});
			
			$('#remove-slide-image').click(function() {
				
				$('#upload_image_id').val('');
				$('img').attr('src', '');
				$(this).hide();
				
				return false;
			});
			
			// handler function which is invoked after the user selects an image from the gallery popup.
			// this function displays the image and sets the id so it can be persisted to the post meta
			window.attach_image = function(html) {
				
				// turn the returned image html into a hidden image element so we can easily pull the relevant attributes we need
				$('body').append('<div id="temp_image">' + html + '</div>');
					
				var img = $('#temp_image').find('img');
				
				imgurl   = img.attr('src');
				imgclass = img.attr('class');
				imgid    = parseInt(imgclass.replace(/\D/g, ''), 10);
	
				$('#upload_image_id').val(imgid);
				$('#remove-slide-image').show();
	
				$('img#slide_image').attr('src', imgurl);
				try{tb_remove();}catch(e){};
				$('#temp_image').remove();
				
				// restore the send_to_editor handler function
				window.send_to_editor = window.send_to_editor_default;
				
			}
	
		});
		</script>
		<?php
		}
		
		add_action( 'add_meta_boxes_psone-slider', 'psone_slider_add_meta_boxes' );
		
		
	
		function psone_slider_save_meta_box_data( $post_id ){
			// verify meta box nonce
			if ( !isset( $_POST['psone_slider_meta_box_nonce'] ) || !wp_verify_nonce( $_POST['psone_slider_meta_box_nonce'], basename( __FILE__ ) ) ){
				return;
			}
			// return if autosave
			if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ){
				return;
			}
		  // Check the user's permissions.
			if ( ! current_user_can( 'edit_post', $post_id ) ){
				return;
			}
			// store custom fields values
			// image string
			if ( isset( $_REQUEST['upload_image_id'] ) ) {
				update_post_meta( $post_id, '_psone-slider_image_id', sanitize_text_field( $_POST['upload_image_id'] ) );
			}
			// store custom fields values
			// text position string
			if ( isset( $_REQUEST['text-position'] ) ) {
				update_post_meta( $post_id, '_psone-slider_text-position', sanitize_text_field( $_POST['text-position'] ) );
			}
			// store custom fields values
			// Slide title string
			if ( isset( $_REQUEST['output-title'] ) ) {
				update_post_meta( $post_id, '_psone-slider_output-title', sanitize_text_field( $_POST['output-title'] ) );
			}
			// store custom fields values
			// options array
			if( isset( $_POST['options'] ) ){
				$options = (array) $_POST['options'];
				// sinitize array
				$options = array_map( 'sanitize_text_field', $options );
				// save data
				update_post_meta( $post_id, '_psone-slider_options', $options );
			}else{
				// delete data
				delete_post_meta( $post_id, '_psone-slider_options' );
			}
		}
		add_action( 'save_post_psone-slider', 'psone_slider_save_meta_box_data' );

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Psone_Slider_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Psone_Slider_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/psone-slider-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Psone_Slider_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Psone_Slider_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		//wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/psone-slider-admin.js', array( 'jquery' ), $this->version, false );

	}
	/**
	 * Register the administration menu for this plugin into the WordPress Dashboard menu.
	 *
	 * @since    1.0.0
	 */
	 
	public function add_plugin_admin_menu() {

		/*
		 * Add a settings page for this plugin to the Settings menu.
		 *
		 * NOTE:  Alternative menu locations are available via WordPress administration menu functions.
		 *
		 *        Administration Menus: http://codex.wordpress.org/Administration_Menus
		 *
		 */
		
		add_options_page( 'PSOne Slider Settings', 'Slider Settings', 'manage_options', $this->plugin_name, array($this, 'display_plugin_setup_page')
    );
	}

	 /**
	 * Add settings action link to the plugins page.
	 *
	 * @since    1.0.0
	 */
	 
	public function add_action_links( $links ) {
		/*
		*  Documentation : https://codex.wordpress.org/Plugin_API/Filter_Reference/plugin_action_links_(plugin_file_name)
		*/
	   $settings_link = array(
		'<a href="' . admin_url( 'options-general.php?page=' . $this->plugin_name ) . '">' . __('Settings', $this->plugin_name) . '</a>',
	   );
	   return array_merge(  $settings_link, $links );

	}

	/**
	 * Render the settings page for this plugin.
	 *
	 * @since    1.0.0
	 */
		function settings_function() { ?>
			
		<?php }
	 
	public function display_plugin_setup_page() {
		include_once( 'partials/psone-slider-admin-display.php' );
	}

	public function options_update() {
		register_setting($this->plugin_name, $this->plugin_name, array($this, 'validate'));
	}
	
	public function validate($input) {
		// All checkboxes inputs
		$valid = array();

		//Cleanup
		$valid['animation_style'] = ($input['animation_style']);
		$valid['animation_speed'] = ($input['animation_speed']);
		$valid['slideshow_speed'] = ($input['slideshow_speed']);
		$valid['direction'] = ($input['direction']);
		$valid['direction_nav'] = (isset($input['direction_nav']) && !empty($input['direction_nav'])) ? 'true' : 'false';
		$valid['pause_on_hover'] = (isset($input['pause_on_hover']) && !empty($input['pause_on_hover'])) ? 'true' : 'false';
		$valid['animation_loop'] = (isset($input['animation_loop']) && !empty($input['animation_loop'])) ? 'true' : 'false';
		$valid['pause_on_action'] = (isset($input['pause_on_action']) && !empty($input['pause_on_action'])) ? 'true' : 'false';
		$valid['control_nav'] = (isset($input['control_nav']) && !empty($input['control_nav'])) ? 'true' : 'false';
		$valid['randomize'] = (isset($input['randomize']) && !empty($input['randomize'])) ? 'true' : 'false';
		$valid['reverse'] = (isset($input['reverse']) && !empty($input['reverse'])) ? 'true' : 'false';
		$valid['touch'] = (isset($input['touch']) && !empty($input['touch'])) ? 'true' : 'false';
		$valid['pause_play'] = (isset($input['pause_play']) && !empty($input['pause_play'])) ? 'true' : 'false';
		$valid['set_defaults'] = (isset($input['set_defaults']) && !empty($input['set_defaults'])) ? 'true' : 'false';
		$valid['smooth_height'] = (isset($input['smooth_height']) && !empty($input['smooth_height'])) ? 'true' : 'false';
		$valid['display_center'] = (isset($input['display_center']) && !empty($input['display_center'])) ? 'true' : 'false';
		$valid['display_top_left'] = (isset($input['display_top_left']) && !empty($input['display_top_left'])) ? 'true' : 'false';
		$valid['display_top_right'] = (isset($input['display_top_right']) && !empty($input['display_top_right'])) ? 'true' : 'false';
		$valid['display_bottom'] = (isset($input['display_bottom']) && !empty($input['display_bottom'])) ? 'true' : 'false';
		$valid['display_bottom_left'] = (isset($input['display_bottom_left']) && !empty($input['display_bottom_left'])) ? 'true' : 'false';
		$valid['display_bottom_right'] = (isset($input['display_bottom_right']) && !empty($input['display_bottom_right'])) ? 'true' : 'false';
		$valid['display_title'] = (isset($input['display_title']) && !empty($input['display_title'])) ? 'true' : 'false';
		$valid['display_body'] = (isset($input['display_body']) && !empty($input['display_body'])) ? 'true' : 'false';
		$valid['display_output_title'] = (isset($input['display_output_title']) && !empty($input['display_output_title'])) ? 'true' : 'false';
		
		return $valid;
	}

}
