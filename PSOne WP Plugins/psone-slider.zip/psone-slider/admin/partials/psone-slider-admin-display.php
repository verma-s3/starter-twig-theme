<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       http://psone.ca
 * @since      1.0.0
 *
 * @package    Psone_Slider
 * @subpackage Psone_Slider/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div class="wrap">

	<h2><?php echo esc_html( get_admin_page_title() ); ?></h2>

	<form method="post" name="cleanup_options" action="options.php">

	<?php
	//Grab all options
		$options = get_option($this->plugin_name);
		// Cleanup
		$display_center = $options['display_center'];
		$display_top_left = $options['display_top_left'];
		$display_top_right = $options['display_top_right'];
		$display_bottom = $options['display_bottom'];
		$display_bottom_left = $options['display_bottom_left'];
		$display_bottom_right = $options['display_bottom_right'];
		$display_title = $options['display_title'];
		$display_body = $options['display_body'];
		$display_output_title = $options['display_output_title'];
		$animation_style = $options['animation_style'];
		$animation_speed = $options['animation_speed'];
		$slideshow_speed = $options['slideshow_speed'];
		$animation_loop = $options['animation_loop'];
		$pause_on_action = $options['pause_on_action'];
		$pause_on_hover = $options['pause_on_hover'];
		$control_nav = $options['control_nav'];
		$direction_nav = $options['direction_nav'];
		$randomize = $options['randomize'];
		$reverse = $options['reverse'];
		$touch = $options['touch'];
		$pause_play = $options['pause_play'];
		$smooth_height = $options['smooth_height'];
		$set_defaults = $options['set_defaults'];
	
		if ($set_defaults == 'true') {
			$animation_style = '"slide"';
			$animation_speed = 600;
			$slideshow_speed = 7000;
			$animation_loop = 'true';
			$pause_on_action = 'true';
			$pause_on_hover = 'false';
			$control_nav = 'true';
			$direction_nav = 'true';
			$randomize = 'false';
			$reverse = 'false';
			$touch = 'true';
			$pause_play = 'false';
			$smooth_height = 'false';
			$set_defaults = 'false';
		}
	
	?>

	<?php
		settings_fields( $this->plugin_name );
		do_settings_sections( $this->plugin_name );
	?>
	
	
	<h2 class="nav-tab-wrapper">Text Display Positions</h2>

	<table>

	<!-- Testimonial display options -->
	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-display_center">
			<span><?php esc_attr_e('Add option Center', $this->plugin_name);?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-display_center" name="<?php echo $this->plugin_name;?>[display_center]" value="1" <?php checked( $display_center, 'true' ); ?> />
		</label>
	</fieldset></td></tr>
	
	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-display_top_left">
			<span><?php esc_attr_e('Add option Top Left', $this->plugin_name);?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-display_top_left" name="<?php echo $this->plugin_name;?>[display_top_left]" value="1" <?php checked( $display_top_left, 'true' ); ?> />
		</label>
	</fieldset></td></tr>
	
	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-display_top_right">
			<span><?php esc_attr_e('Add option Top Right', $this->plugin_name);?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-display_top_right" name="<?php echo $this->plugin_name;?>[display_top_right]" value="1" <?php checked( $display_top_right, 'true' ); ?> />
		</label>
	</fieldset></td></tr>
	
	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-display_bottom">
			<span><?php esc_attr_e('Add option Bottom', $this->plugin_name);?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-display_bottom" name="<?php echo $this->plugin_name;?>[display_bottom]" value="1" <?php checked( $display_bottom, 'true' ); ?> />
		</label>
	</fieldset></td></tr>
	
	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-display_bottom_left">
			<span><?php esc_attr_e('Add option Bottom Left', $this->plugin_name);?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-display_bottom_left" name="<?php echo $this->plugin_name;?>[display_bottom_left]" value="1" <?php checked( $display_bottom_left, 'true' ); ?> />
		</label>
	</fieldset></td></tr>
	
	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-display_bottom_right">
			<span><?php esc_attr_e('Add option Bottom Right', $this->plugin_name);?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-display_bottom_right" name="<?php echo $this->plugin_name;?>[display_bottom_right]" value="1" <?php checked( $display_bottom_right, 'true' ); ?> />
		</label>
	</fieldset></td></tr>
	
	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-display_title">
			<span><?php esc_attr_e('Display title on slider', $this->plugin_name);?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-display_title" name="<?php echo $this->plugin_name;?>[display_title]" value="1" <?php checked( $display_title, 'true' ); ?> />
		</label>
	</fieldset></td></tr>
	
	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-display_body">
			<span><?php esc_attr_e('Display body on slider', $this->plugin_name);?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-display_body" name="<?php echo $this->plugin_name;?>[display_body]" value="1" <?php checked( $display_body, 'true' ); ?> />
		</label>
	</fieldset></td></tr>
	
	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-display_output_title">
			<span><?php esc_attr_e('Use alternate title', $this->plugin_name);?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-display_output_title" name="<?php echo $this->plugin_name;?>[display_output_title]" value="1" <?php checked( $display_output_title, 'true' ); ?> />
		</label>
	</fieldset></td></tr>
	</table>
	
	
	<h2 class="nav-tab-wrapper">Slider Options</h2>
	
	<table>

	<!-- slider options -->
	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-animation_speed">
			<span><?php esc_attr_e('Set the speed of animations, in milliseconds', $this->plugin_name);?></span></td>
			<td><input type="text" id="<?php echo $this->plugin_name;?>-animation_speed" name="<?php echo $this->plugin_name;?>[animation_speed]" value="<?php if(!empty($animation_speed)) echo $animation_speed;?>"/>
		</label>
	</fieldset></td></tr>
	
	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-slideshow_speed">
			<span><?php esc_attr_e('Set the speed of the slideshow cycling, in milliseconds', $this->plugin_name);?></span></td>
			<td><input type="text" id="<?php echo $this->plugin_name;?>-slideshow_speed" name="<?php echo $this->plugin_name;?>[slideshow_speed]" value="<?php if(!empty($slideshow_speed)) echo $slideshow_speed;?>"/>
		</label>
	</fieldset></td></tr>

	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-animation_style">
			<span><?php esc_attr_e( 'Controls the animation type', $this->plugin_name ); ?></span></td>
			<td><select id="<?php echo $this->plugin_name;?>-animation_style" name="<?php echo $this->plugin_name;?>[animation_style]" value="<?php echo $animation_style;?>">
			<option value='"slide"'<?php if($options['animation_style'] == '"slide"'){ echo ' selected="selected"'; } ?>>Slide</option>
			<option value='"fade"'<?php if($options['animation_style'] == '"fade"'){ echo ' selected="selected"'; } ?>>Fade</option>
			</select>
		</label>
	</fieldset></td></tr>

	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-direction_nav">
			<span><?php esc_attr_e( 'Enable previous/next arrow navigation', $this->plugin_name ); ?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-direction_nav" name="<?php echo $this->plugin_name;?>[direction_nav]" value="1" <?php checked( $direction_nav, 'true' ); ?> />
		</label>
	</fieldset></td></tr>

	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-animation_loop">
			<span><?php esc_attr_e( 'Infinite loop', $this->plugin_name ); ?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-animation_loop" name="<?php echo $this->plugin_name;?>[animation_loop]" value="1" <?php checked( $animation_loop, 'true' ); ?> />
		</label>
	</fieldset></td></tr>

	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-pause_on_action">
			<span><?php esc_attr_e( 'Pause the slideshow when interacting with control elements', $this->plugin_name ); ?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-pause_on_action" name="<?php echo $this->plugin_name;?>[pause_on_action]" value="1" <?php checked( $pause_on_action, 'true' ); ?> />
		</label>
	</fieldset></td></tr>

	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-pause_on_hover">
			<span><?php esc_attr_e( 'Pause the slideshow when hovering over slider, then resume when no longer hovering', $this->plugin_name ); ?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-pause_on_hover" name="<?php echo $this->plugin_name;?>[pause_on_hover]" value="1" <?php checked( $pause_on_hover, 'true' ); ?> />
		</label>
	</fieldset></td></tr>

	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-control_nav">
			<span><?php esc_attr_e( 'Create navigation for paging control of each slide', $this->plugin_name ); ?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-control_nav" name="<?php echo $this->plugin_name;?>[control_nav]" value="1" <?php checked( $control_nav, 'true' ); ?> />
		</label>
	</fieldset></td></tr>

	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-randomize">
			<span><?php esc_attr_e( 'Randomize slide order, on load', $this->plugin_name ); ?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-randomize" name="<?php echo $this->plugin_name;?>[randomize]" value="1" <?php checked( $randomize, 'true' ); ?> />
		</label>
	</fieldset></td></tr>

	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-reverse">
			<span><?php esc_attr_e( 'Reverse the animation direction', $this->plugin_name ); ?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-reverse" name="<?php echo $this->plugin_name;?>[reverse]" value="1" <?php checked( $reverse, 'true' ); ?> />
		</label>
	</fieldset></td></tr>

	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-touch">
			<span><?php esc_attr_e( 'Allow touch swipe navigation of the slider on enabled devices', $this->plugin_name ); ?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-touch" name="<?php echo $this->plugin_name;?>[touch]" value="1" <?php checked( $touch, 'true' ); ?> />
		</label>
	</fieldset></td></tr>

	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-pause_play">
			<span><?php esc_attr_e( 'Create pause/play element to control slider slideshow', $this->plugin_name ); ?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-pause_play" name="<?php echo $this->plugin_name;?>[pause_play]" value="1" <?php checked( $pause_play, 'true' ); ?> />
		</label>
	</fieldset></td></tr>

	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-smooth_height">
			<span><?php esc_attr_e( 'Animate the height of the slider smoothly for slides of varying height', $this->plugin_name ); ?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-smooth_height" name="<?php echo $this->plugin_name;?>[smooth_height]" value="1" <?php checked( $smooth_height, 'true' ); ?> />
		</label>
	</fieldset></td></tr>
	</table>
	
	<h2 class="nav-tab-wrapper">Defaults</h2>
	
	<table>

	<!-- Testimonial slider options -->
	<tr><td><fieldset>
		<label for="<?php echo $this->plugin_name;?>-set_defaults">
			<span><?php esc_attr_e( 'Set/Reset ALL slider options to defaults', $this->plugin_name ); ?></span></td>
			<td><input type="checkbox" id="<?php echo $this->plugin_name;?>-set_defaults" name="<?php echo $this->plugin_name;?>[set_defaults]" value="1" <?php checked( $set_defaults, 'true' ); ?> />
		</label>
	</fieldset></td></tr>
	</table>

    <?php submit_button('Save all changes', 'primary','submit', TRUE); ?>

    </form>
	<p>
	<?php echo "Use [psone-slider] to display on page."; ?>
	</p>
